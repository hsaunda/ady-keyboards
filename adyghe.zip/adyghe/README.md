Adyghe keyboard
==============

©

Version 1.0

Description
-----------

Adyghe generated from template

Links
-----

Supported Platforms
-------------------
 * Windows
 * macOS
 * Linux
 * Android phone
 * Android tablet

