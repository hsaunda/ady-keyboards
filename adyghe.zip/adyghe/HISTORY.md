Adyghe Change History
====================

1.0 (2022-05-13)
----------------
* Created by Daniel Khazanov and Harrison Saunders
